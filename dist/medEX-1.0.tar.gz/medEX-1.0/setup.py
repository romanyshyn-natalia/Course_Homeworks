#!/usr/bin/env python

from distutils.core import setup

setup(name='medEX',
      version='1.0',
      description='Medical extrator package',
      author='Natalia Romanyshyn',
      author_email='romanyshyn.n@ucu.edu.ua',
      py_modules=['abstract_collection', 'linkedQueue', 'RecordADT'],
      scripts=['main.py'],
 )
